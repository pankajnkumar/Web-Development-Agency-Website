document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('#nav-bar ul');
    const navLinks = document.querySelectorAll('#nav-bar ul li a');

    // Toggle menu
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu when clicking a link and update active class
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // Remove 'active' from all links
            navLinks.forEach(l => l.classList.remove('active'));
            // Add 'active' to the clicked link
            e.target.classList.add('active');
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!hamburger.contains(event.target) && !navMenu.contains(event.target)) {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        }
    });

    // Handle footer quick links
    const footerLinks = document.querySelectorAll('.footer-link');
    footerLinks.forEach(footerLink => {
        footerLink.addEventListener('click', function(e) {
            e.preventDefault();
            // Remove 'active' from all navbar links
            navLinks.forEach(l => l.classList.remove('active'));
            // Find the corresponding navbar link by href
            const href = this.getAttribute('href');
            const matchingNav = Array.from(navLinks).find(link => link.getAttribute('href') === href);
            if (matchingNav) {
                matchingNav.classList.add('active');
            }
            // Scroll to the section smoothly
            if (href && href.startsWith('#')) {
                const section = document.querySelector(href);
                if (section) {
                    section.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
}); 